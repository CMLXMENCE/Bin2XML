#include <stdio.h>
#include <math.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>


//struct for record
struct record
{
    char name[64];      //utf16
    char surname[32];   //utf8
    char gender;
    char email[32];
    char phone_number[16];
    char address[32];
    char level_of_education[8];
    unsigned int income_level;  // given little-endian
    unsigned int expenditure;   // given big-endian
    char currency_unit[16];
    char currentMood[32];
    float height;
    unsigned int weight;
};

//struct for tag all string
struct tags
{
    char name[32];      //utf16
    char surname[32];   //utf8
    char gender[32];
    char email[32];
    char phone_number[32];
    char address[32];
    char level_of_education[32];
    char income_level[32];  // given little-endian
    char expenditure[32];   // given big-endian
    char currency_unit[32];
    char currentMood[32];
    char height[32];
    char weight[32];
};


int reverseEndian(int value) //function for swapping endian formats
{
  int l_most;
  int l_middle;
  int r_middle;
  int r_most;
  int result;
  l_most = (value & 0x000000FF) >> 0;
  l_middle = (value & 0x0000FF00) >> 8;
  r_middle = (value & 0x00FF0000) >> 16;
  r_most = (value & 0xFF000000) >> 24;
  l_most <<= 24;
  l_middle <<= 16;
  r_middle <<= 8;
  r_most <<= 0;
  result = (l_most | l_middle | r_middle | r_most);
  return result;
}


int main();

struct record *readRecords(char path[]);

struct tags *readTags(char path[]);

int main(int argc, char* argv[]) {
    printf("you converted your file successfully");

    //create xml file
    FILE *fp = fopen("records.xml", "w");
    fprintf(fp, "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
    struct record *records = readRecords(argv[1]);
    struct tags *tag = readTags(argv[1]);
    fprintf(fp, "\t%s","<records>\n");
    int i=1;
    						// write xml file
    while(i < 51){
         int reversedIncomeLevel =  reverseEndian(records[i].income_level);
         int reversedExpenditure =  reverseEndian(records[i].expenditure);
        fprintf(fp, "\t\t<row id = %c%d%c>\n", 34,(i),34);
        fprintf(fp, "\t\t\t<%s>%s</%s>\n",tag->name, records[i].name, tag->name);
        fprintf(fp, "\t\t\t<%s>%s</%s>\n",tag->surname, records[i].surname, tag->surname);
        fprintf(fp, "\t\t\t<%s>%c</%s>\n",tag->gender, records[i].gender, tag->gender);
        fprintf(fp, "\t\t\t<%s>%s</%s>\n",tag->email, records[i].email, tag->email);
        fprintf(fp, "\t\t\t<%s>%s</%s>\n",tag->phone_number, records[i].phone_number, tag->phone_number);
        fprintf(fp, "\t\t\t<%s>%s</%s>\n",tag->address, records[i].address, tag->address);
        fprintf(fp, "\t\t\t<%s>%s</%s>\n",tag->level_of_education, records[i].level_of_education, tag->level_of_education);
        fprintf(fp, "\t\t\t<%s%s%c%u%c>%u</%s>\n",tag->income_level, " bigEnd=", 34, reversedIncomeLevel, 34, records[i].income_level, tag->income_level);
        fprintf(fp, "\t\t\t<%s%s%c%u%c>%u</%s>\n",tag->expenditure, " bigEnd=", 34,records[i].expenditure, 34,reversedExpenditure, tag->expenditure);
        fprintf(fp, "\t\t\t<%s>%s</%s>\n",tag->currency_unit, records[i].currency_unit, tag->currency_unit);
        fprintf(fp, "\t\t\t<%s>%s</%s>\n",tag->currentMood, records[i].currentMood, tag->currentMood);
        fprintf(fp, "\t\t\t<%s>%f</%s>\n",tag->height, records[i].height, tag->height);
        fprintf(fp, "\t\t\t<%s>%u</%s>\n",tag->weight, records[i].weight, tag->weight);
        i++;
        fprintf(fp, "\t\t</row>\n");
    }
    fprintf(fp, "\t%s", "</records>");
    return 0;    
}

struct record *readRecords(char path[]) //read function for records
{
	path="records.dat";
    struct record *recs = calloc(51, sizeof(struct record));
    FILE *binFile;
    binFile = fopen(path, "rb");
    if(binFile == NULL)
    {
        printf("File not found exception� Cannot find source file.");
        exit(1);
        return recs;
    }
    struct record rec;
int i=0;
    while( i < 51){
        fread(&rec, sizeof(struct record), 1, binFile);
        if(i != 0){
        recs[i] = rec;
        }
        i++;
    }
    fclose(binFile);
    return recs;
}

struct tags *readTags(char path[])//read function for tags
{
	path="records.dat";
    struct tags *tag = calloc(101, sizeof(struct tags));   
    FILE *binFile;
    binFile = fopen(path, "rb");
    if(binFile == NULL)
    {
        printf("File not found exception� Cannot find source file.");
        exit(1);
        return tag;
    }
    fread(tag, sizeof(struct tags), 1, binFile);
    fclose(binFile);
    strcpy(tag->gender, "gender");
    strcpy(tag->email, "email");
    strcpy(tag->surname, "surname");
    strcpy(tag->phone_number, "phone_number");
    strcpy(tag->address, "address");
    strcpy(tag->level_of_education, "level_of_education");
    strcpy(tag->income_level, "income_level");
    strcpy(tag->expenditure, "expenditure");
    strcpy(tag->currency_unit, "currency_unit");
    strcpy(tag->currentMood, "currentMood");
    strcpy(tag->height, "height");
    strcpy(tag->weight, "weight");

    return tag;
}

